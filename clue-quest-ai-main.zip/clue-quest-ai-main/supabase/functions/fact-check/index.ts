import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { content } = await req.json();
    
    // Check for India Government restricted content
    const restrictedPatterns = [
      // Military & Defence
      /\b(army|navy|air force|military)\s*(base|camp|bunker|ammunition|depot|location|coordinate|map|layout|deployment|troop|movement|strategy|patrol|timing|frequency|encryption|radio code)\b/i,
      /\b(secret|classified)\s*(document|file|information|data)\b/i,
      
      // Intelligence Agencies
      /\b(RAW|IB|NIA|DRDO)\s*(structure|operation|protocol|employee|identity|internal)\b/i,
      
      // Nuclear & Critical Infrastructure
      /\b(nuclear facility|nuclear plant)\s*(blueprint|security|vulnerability|internal)\b/i,
      /\b(power grid|railway signal|airport)\s*(control system|vulnerability|internal layout)\b/i,
      /\b(BSF|ITBP)\s*(border security plan|fencing gap|surveillance|blind spot)\b/i,
      
      // Cybersecurity & Hacking
      /\b(password|login credential|OTP bypass|hack|hacking method|malware)\b/i,
      /\b(government portal|defence system)\s*(access|breach|vulnerability)\b/i,
      
      // Personal Data
      /\b(aadhaar|pan|bank detail|medical record)\s*(number|data|information)\b/i,
      
      // Terrorism & Violence
      /\b(bomb|explosive|weapon)\s*(making|construction|instruction|guide)\b/i,
      /\b(terrorist|terrorism|sabotage|attack)\s*(plan|method|instruction|guide)\b/i,
    ];

    const isRestricted = restrictedPatterns.some(pattern => pattern.test(content));

    if (isRestricted) {
      console.log('Restricted content detected');
      return new Response(JSON.stringify({
        restricted: true,
        message: "Yeh information Bharat Sarkar dwara restricted hai. Main is bare mein koi details provide nahi kar sakta.",
        advice: "Agar aapko general, non-sensitive public information chahiye, main woh help kar sakta hoon.",
        claims: [],
        final_summary: "Content restricted by India Government regulations"
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');

    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY is not configured');
    }

    console.log('Analyzing content for fake news...');

    const systemPrompt = `You are an advanced Fake News Detection AI.

Your job is to:
1) Extract factual claims from the provided user content.
2) Analyze those claims using trusted online sources.
3) Detect whether the claim is TRUE, FALSE, POSSIBLY FALSE, or NOT ENOUGH EVIDENCE.
4) Provide short and clear explanation + evidence URLs.
5) Return final output in STRICT JSON ONLY.

### STEP–1 → CLAIM EXTRACTION
- Extract 1–5 main factual claims.
- Claims must be short, factual, verifiable.
- Ignore opinions/emotions.

### STEP–2 → FACT CHECKING RULES
You MUST follow these:
- Use ONLY trusted high-authority sources such as:
  Reuters, AP News, PolitiFact, Snopes, PIB Fact Check (India), Government websites.
- Do NOT hallucinate any fact.
- If evidence is weak, say "Not Enough Evidence".
- Each claim must include: label + confidence (0–1) + evidence URLs.

### STEP–3 → OUTPUT FORMAT (STRICT JSON)
Return exactly this JSON structure:

{
  "claims": [
    {
      "id": "c1",
      "claim": "text of extracted claim",
      "label": "True | False | Possibly False | Not Enough Evidence",
      "confidence": 0.0,
      "explanation": "Short explanation in Hinglish",
      "evidence": [
        {
          "url": "https://...",
          "snippet": "short supporting/contradicting evidence"
        }
      ]
    }
  ],
  "final_summary": "Overall verdict in Hinglish (1-2 lines)"
}

### STEP–4 → IMPORTANT INSTRUCTIONS
- Do not output anything outside JSON.
- Do not include unnecessary text.
- Do not invent URLs.
- Use ONLY real available evidence.
- If URL content is unclear, mark all claims as Not Enough Evidence.`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `${systemPrompt}\n\n-------------------------------------------\nCONTENT (From User):\n${content}\n-------------------------------------------\n\nNow begin analysis.`
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.3,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error:', response.status, errorText);
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('Gemini response received');

    const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    // Extract JSON from markdown code blocks if present
    let jsonText = generatedText;
    const jsonMatch = generatedText.match(/```json\n([\s\S]*?)\n```/);
    if (jsonMatch) {
      jsonText = jsonMatch[1];
    }

    // Try to parse the JSON response
    let result;
    try {
      result = JSON.parse(jsonText);
    } catch (parseError) {
      console.error('Failed to parse JSON:', jsonText);
      throw new Error('Failed to parse AI response as JSON');
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in fact-check function:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        claims: [],
        final_summary: 'Error occurred during fact-checking'
      }), 
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
